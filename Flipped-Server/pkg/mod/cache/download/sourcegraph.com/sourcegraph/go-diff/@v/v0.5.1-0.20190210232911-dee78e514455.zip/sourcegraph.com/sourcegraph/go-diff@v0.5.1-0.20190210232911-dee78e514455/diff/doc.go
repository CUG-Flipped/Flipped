// Package diff provides a parser for unified diffs.
package diff // import "sourcegraph.com/sourcegraph/go-diff/diff"
