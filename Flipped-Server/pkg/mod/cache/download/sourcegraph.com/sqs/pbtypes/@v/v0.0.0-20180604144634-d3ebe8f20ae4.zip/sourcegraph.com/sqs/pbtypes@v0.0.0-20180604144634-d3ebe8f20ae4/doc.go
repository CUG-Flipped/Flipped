// Package pbtypes contains protocol buffer types (Timestamp, Void,
// etc.) and related helpers.
package pbtypes // import "sourcegraph.com/sqs/pbtypes"
