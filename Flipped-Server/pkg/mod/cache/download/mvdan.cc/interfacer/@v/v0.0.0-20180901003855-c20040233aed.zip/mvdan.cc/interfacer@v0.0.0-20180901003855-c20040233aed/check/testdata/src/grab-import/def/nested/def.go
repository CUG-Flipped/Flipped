package nested

type Fooer interface {
	Foo()
}
