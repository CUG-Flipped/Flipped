package fluent

var boolResult bool
