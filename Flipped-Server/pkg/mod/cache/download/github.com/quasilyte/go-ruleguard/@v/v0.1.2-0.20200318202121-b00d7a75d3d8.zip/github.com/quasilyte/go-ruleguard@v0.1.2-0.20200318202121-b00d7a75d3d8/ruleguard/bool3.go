package ruleguard

type bool3 int

const (
	bool3unset bool3 = iota
	bool3false
	bool3true
)
