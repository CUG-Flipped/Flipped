<!--
Use "--debug" to debug gometalinter before filing an issue.
Please read CONTRIBUTING.md for full instructions on debugging.
-->
