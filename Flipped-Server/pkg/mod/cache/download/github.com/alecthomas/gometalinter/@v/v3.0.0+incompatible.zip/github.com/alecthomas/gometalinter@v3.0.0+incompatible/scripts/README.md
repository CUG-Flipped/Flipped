Auto-generated install script. Regenerate with [godownloader](https://github.com/goreleaser/godownloader):

    godownloader .goreleaser.yml
