package pkg

import "testing"

func TestPkg(t *testing.T) {
	fn()
}
