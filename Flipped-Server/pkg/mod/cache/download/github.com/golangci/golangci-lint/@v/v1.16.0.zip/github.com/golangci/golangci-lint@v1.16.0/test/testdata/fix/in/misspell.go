//args: -Emisspell
package p

// langauge lala
// lala langauge
// langauge
// langauge langauge

// check Langauge
// and check langAuge

func langaugeMisspell() { // the function detects langauge of the text

}
