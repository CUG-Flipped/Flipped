package withtests

import "fmt"

func init() {
	fmt.Printf("init")
}
