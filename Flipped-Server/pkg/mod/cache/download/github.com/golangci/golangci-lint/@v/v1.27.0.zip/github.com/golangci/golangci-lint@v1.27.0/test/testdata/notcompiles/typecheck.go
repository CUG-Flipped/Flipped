//args: -Etypecheck
package testdata

fun NotCompiles() { // ERROR "expected declaration, found.* fun"
}
