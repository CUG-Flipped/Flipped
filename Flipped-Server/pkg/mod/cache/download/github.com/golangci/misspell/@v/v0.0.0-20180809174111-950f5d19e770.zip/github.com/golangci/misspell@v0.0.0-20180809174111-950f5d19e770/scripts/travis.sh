#!/bin/sh
set -ex
./scripts/setup.sh
./scripts/build.sh
