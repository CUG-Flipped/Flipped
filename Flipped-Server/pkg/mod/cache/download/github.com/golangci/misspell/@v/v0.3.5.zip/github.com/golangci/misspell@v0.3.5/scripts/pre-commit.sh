#!/bin/sh -ex
./scripts/build.sh
