#!/bin/sh -ex
misspell -error "$1"
