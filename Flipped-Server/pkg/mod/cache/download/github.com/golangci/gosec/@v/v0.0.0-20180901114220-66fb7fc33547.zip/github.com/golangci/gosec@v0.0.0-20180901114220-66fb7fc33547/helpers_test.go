package gosec_test

import (
	. "github.com/onsi/ginkgo"
	//. "github.com/onsi/gomega"
)

var _ = Describe("Helpers", func() {
	Context("todo", func() {
		It("should fail", func() {
			Skip("Not implemented")
		})
	})
})
