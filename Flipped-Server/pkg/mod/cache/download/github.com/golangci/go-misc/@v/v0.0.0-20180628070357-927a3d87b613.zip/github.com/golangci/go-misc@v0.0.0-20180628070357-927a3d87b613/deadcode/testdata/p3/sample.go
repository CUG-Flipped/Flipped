package p

// x is used only in tests
var x = 42

// y is unused
var y = 43
