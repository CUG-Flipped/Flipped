package nsq

// VERSION
const VERSION = "1.0.8"
