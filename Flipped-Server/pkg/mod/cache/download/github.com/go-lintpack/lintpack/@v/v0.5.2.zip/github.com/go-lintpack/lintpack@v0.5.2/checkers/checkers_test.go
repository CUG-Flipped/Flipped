package checkers

import (
	"testing"

	"github.com/go-lintpack/lintpack/linttest"
)

func TestCheckers(t *testing.T) { linttest.TestCheckers(t) }
