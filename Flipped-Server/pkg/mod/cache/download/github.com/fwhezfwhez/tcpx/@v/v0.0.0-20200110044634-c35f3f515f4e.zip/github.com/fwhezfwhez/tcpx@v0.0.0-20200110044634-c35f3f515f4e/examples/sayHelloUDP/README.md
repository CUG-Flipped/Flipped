sayHelloUDP shows how client communicates with server in udp protocol.


`cd server`

`go run main.go`

`cd client`

`go run main.go`
