## heartbeat
This example shows how to use official way to watch heartbeat. You can also design it yourself.

#### step

`cd server`

`go run server.go`

`cd client`

`go run client.go`

#### result
server side outputs heartbeat pack info each 10s.
