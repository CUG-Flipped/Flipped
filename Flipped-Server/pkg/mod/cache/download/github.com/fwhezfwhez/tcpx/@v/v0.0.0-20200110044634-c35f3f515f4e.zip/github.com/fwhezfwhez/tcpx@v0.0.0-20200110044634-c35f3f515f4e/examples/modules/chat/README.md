## Chat
This part tells how to use tcpx to start a chat.

## Step

`go run server/main.go` run server

`go run client_1/main.go` run client_1

`go run client_2/main.go` run client_2

You can now type message in one of clients and receive in another.
