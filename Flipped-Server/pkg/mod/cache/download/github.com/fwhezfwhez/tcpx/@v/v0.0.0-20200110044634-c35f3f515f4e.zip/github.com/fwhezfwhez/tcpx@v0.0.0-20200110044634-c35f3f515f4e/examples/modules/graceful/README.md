## graceful
Here are examples of graceful. Their details are in their own package.

- graceful-exit

- graceful-stop

- graceful-restart
