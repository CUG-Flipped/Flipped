sayHello shows how client communicates with server.
This example provides tcp, udp, and kcp server side examples.But only tcp client side are provided.Udp and kcp client sides are in /examples/sayHelloUDP/client/ and /examples/sayHelloKCP/client/

## start server and client
**server side(tcp, udp and kcp):**

`cd server`

`go run main.go`


**tcp client:**

`cd client`

`go run main.go`

**udp**

`cd example/sayHelloUDP/client`

`go run main.go`

**kcp**

`cd example/sayHelloKCP/client`

`go run main.go`

## ATTENTION
/examples/sayHello will changed with developing to test new function, some old tips will remain as note.
