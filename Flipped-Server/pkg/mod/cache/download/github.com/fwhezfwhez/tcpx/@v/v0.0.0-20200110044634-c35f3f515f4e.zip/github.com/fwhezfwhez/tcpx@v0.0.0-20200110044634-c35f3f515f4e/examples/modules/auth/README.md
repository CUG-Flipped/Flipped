## auth
This example shows how to auth in tcpx.

#### step

`cd server`

`go run server.go`

`cd client`

`go run client.go`

#### result
server side outputs `connection auth fail, closed` when appsecret is not consistent.
