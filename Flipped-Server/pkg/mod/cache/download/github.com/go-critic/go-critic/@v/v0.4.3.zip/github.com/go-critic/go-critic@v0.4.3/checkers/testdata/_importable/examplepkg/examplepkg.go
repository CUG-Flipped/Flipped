package examplepkg

type StructType struct {
	A int
	B int
}

type InterfaceType interface {
	Method() int
}
