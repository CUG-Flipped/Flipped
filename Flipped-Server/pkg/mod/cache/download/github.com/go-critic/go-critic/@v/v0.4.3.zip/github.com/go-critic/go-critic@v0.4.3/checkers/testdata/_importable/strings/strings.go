package strings

func Contains(s string) {}
