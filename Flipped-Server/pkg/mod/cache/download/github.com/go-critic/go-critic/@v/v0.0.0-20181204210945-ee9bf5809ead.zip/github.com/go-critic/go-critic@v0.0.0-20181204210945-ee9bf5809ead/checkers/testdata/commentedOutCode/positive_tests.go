package checker_test

func singleLineCode() {
	/*! may want to remove commented-out code */
	//fmt.Printf("Operand: %v\n", p.input)

	/*! may want to remove commented-out code */
	// warnings := make(map[int][]*warning)

	/*! may want to remove commented-out code */
	// return &goldenFile{warnings: warnings}
}

func multiLineCode() {
	/*! may want to remove commented-out code */
	// if !strings.HasPrefix(l, "// ") {
	// }

	/*! may want to remove commented-out code */
	/*
		if false {
			log.Printf("this is forgotten debug code")
		}
	*/
}
