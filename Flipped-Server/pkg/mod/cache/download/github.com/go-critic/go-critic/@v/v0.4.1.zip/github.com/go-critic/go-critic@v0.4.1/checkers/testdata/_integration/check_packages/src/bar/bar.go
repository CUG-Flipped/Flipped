package bar

// PackageName ...
func PackageName() string {
	return "bar"
}
