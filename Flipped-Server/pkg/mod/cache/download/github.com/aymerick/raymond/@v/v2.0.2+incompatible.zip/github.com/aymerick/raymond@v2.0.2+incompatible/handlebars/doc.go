// Package handlebars contains all the tests that come from handlebars.js project.
package handlebars
