Examples for the `sitemap` project can be found at
<https://github.com/kataras/sitemap/tree/master/_examples>.

Documentation for the `sitemap` project can be found at
<https://godoc.org/github.com/kataras/sitemap>.

Love the `sitemap` package? Please consider supporting the project:
👉  https://paypal.me/kataras
