// +build windows

package main

func main() {
	panic("windows operating system does not support this feature")
}
