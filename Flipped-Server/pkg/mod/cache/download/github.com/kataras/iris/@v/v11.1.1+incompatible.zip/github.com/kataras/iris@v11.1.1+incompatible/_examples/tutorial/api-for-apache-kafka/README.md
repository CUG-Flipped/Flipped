# Writing an API for Apache Kafka with Iris

Article is coming soon, follow and stay tuned

- <https://medium.com/@kataras>
- <https://dev.to/kataras>

Read [the fully functional example](src/main.go).

## Screens

![](0_docs.png)

![](1_create_topic.png)

![](2_list_topics.png)

![](3_store_to_topic.png)

![](4_retrieve_from_topic_real_time.png)

