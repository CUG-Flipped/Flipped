# Jet Engine Example

This example is a fork of <https://github.com/CloudyKit/jet/tree/master/examples/todos> to work with Iris, so you can
notice the differences side by side.

Read more at: https://github.com/kataras/iris/issues/1281

> The Iris Jet View Engine fixes some bugs that the underline [jet template parser](https://github.com/CloudyKit/jet) currently has.


Continue by learning how you can [serve embedded templates](../template_jet_1_embedded).