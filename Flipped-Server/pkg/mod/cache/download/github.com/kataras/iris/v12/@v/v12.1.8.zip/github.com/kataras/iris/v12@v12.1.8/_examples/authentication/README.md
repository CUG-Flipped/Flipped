# Authentication

- [Basic Authentication](basicauth/main.go)
- [OAUth2](oauth2/main.go)
- [Request Auth(JWT)](https://github.com/iris-contrib/middleware/blob/master/jwt)
- [Sessions](https://github.com/kataras/iris/tree/master/_examples/#sessions)