package testdata

type TеstStruct struct{} // want `identifier "TеstStruct" contain non-ASCII character: U\+0435 \'е\'`
