package _return

func example() int {
	return 3 // want "Magic number: 3"
}

func example2() string {
	return "3"
}

func example3() float64 {
	return 2.0 // want "Magic number: 2.0"
}
