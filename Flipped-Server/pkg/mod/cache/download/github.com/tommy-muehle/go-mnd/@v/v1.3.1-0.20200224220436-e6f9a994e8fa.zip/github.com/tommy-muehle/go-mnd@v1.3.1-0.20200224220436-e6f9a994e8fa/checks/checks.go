package checks

const reportMsg = "Magic number: %v, in <%s> detected"
