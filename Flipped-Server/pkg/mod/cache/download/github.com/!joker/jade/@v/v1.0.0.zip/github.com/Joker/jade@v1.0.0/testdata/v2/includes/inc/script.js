// script.js
console.log('You are awesome');
