see: https://github.com/templexxx/cpu
