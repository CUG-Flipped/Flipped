# Whitespace linter

Whitespace is a linter that checks for unnecessary newlines at the start and end of functions, if, for, etc.

## Installation guide

Whitespace is included in [https://github.com/golangci/golangci-lint/](golangci-lint). Install it and enable whitespace.
