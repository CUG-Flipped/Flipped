// Package typep provides type predicates.
package typep
