// +build !go1.8

package simpler

import "go/types"

var structsIdentical = types.Identical
