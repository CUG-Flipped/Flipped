package copycheck

import (
	"testing"
)

func Test_CopyCheck(t *testing.T) {
	CopyCheck("../copycheck", "job")
}
