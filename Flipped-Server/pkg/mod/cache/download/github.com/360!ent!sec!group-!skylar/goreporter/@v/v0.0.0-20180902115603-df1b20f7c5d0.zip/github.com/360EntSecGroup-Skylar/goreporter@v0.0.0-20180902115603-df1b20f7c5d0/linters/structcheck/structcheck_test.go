package structcheck

import (
	"testing"
)

func Test_StructCheck(t *testing.T) {
	StructCheck("fmt")
}
