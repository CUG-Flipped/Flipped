package spellcheck

import (
	"testing"
)

func Test_SpellCheck(t *testing.T) {
	SpellCheck("../../../goreporter", "")
}
