package depth

import (
	"testing"
)

func Test_Depth(t *testing.T) {
	Depth("../copycheck")
}
