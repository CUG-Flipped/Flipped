package errorcheck

import (
	"testing"
)

func Test_ErrorcCeck(t *testing.T) {
	ErrorCheck("./test")
}
