package cyclo

import (
	"testing"
)

func Test_Cyclo(t *testing.T) {
	Cyclo("../copycheck")
}
