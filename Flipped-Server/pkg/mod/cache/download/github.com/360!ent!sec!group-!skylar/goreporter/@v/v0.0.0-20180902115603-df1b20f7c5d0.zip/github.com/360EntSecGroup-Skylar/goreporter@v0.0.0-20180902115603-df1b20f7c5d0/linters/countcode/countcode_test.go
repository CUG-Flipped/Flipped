package countcode

import (
	"testing"
)

func Test_CountCode(t *testing.T) {
	CountCode("../../../goreporter", "")
}
