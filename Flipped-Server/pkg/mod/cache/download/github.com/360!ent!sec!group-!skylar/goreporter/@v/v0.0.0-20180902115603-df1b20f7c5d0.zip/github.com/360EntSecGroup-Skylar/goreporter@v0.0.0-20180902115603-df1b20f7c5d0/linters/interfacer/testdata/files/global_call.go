package foo

func someFunc() error {
	return nil
}

var globalErr = someFunc()
