package simplecode

import (
	"testing"
)

func Test_Simple(t *testing.T) {
	Simple(map[string]string{"./testdata": "./testdata"})
}
