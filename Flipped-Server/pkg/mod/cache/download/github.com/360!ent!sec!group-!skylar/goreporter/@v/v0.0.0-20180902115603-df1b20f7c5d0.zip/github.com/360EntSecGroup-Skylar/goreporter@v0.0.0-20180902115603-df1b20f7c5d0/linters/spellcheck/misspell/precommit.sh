#!/bin/sh
make ci
