package deadcode

import (
	"testing"
)

func Test_P1(t *testing.T) {
	DeadCode("./testdata/p1")
}

func Test_P2(t *testing.T) {
	DeadCode("./testdata/p2")
}

func Test_P3(t *testing.T) {
	DeadCode("./testdata/p3")
}
