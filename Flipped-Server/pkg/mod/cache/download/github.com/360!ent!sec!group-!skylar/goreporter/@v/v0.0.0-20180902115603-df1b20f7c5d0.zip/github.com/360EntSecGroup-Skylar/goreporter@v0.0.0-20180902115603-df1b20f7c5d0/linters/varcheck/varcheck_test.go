package varcheck

import (
	"testing"
)

func Test_VarCheck(t *testing.T) {
	VarCheck("image/jpeg")
}
